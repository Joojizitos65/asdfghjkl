# Relatório — datalake de tracking da DadosPro

Período analisado: 01/09/2026 a 14/09/2026 (UTC), dados gerados com `seed 42`. Todos os números abaixo vêm das tabelas Gold em `s3://datalake-tracking/gold/`, geradas por `python pipeline/rodar_pipeline.py --do-zero`. Percentuais são sobre sessões, salvo indicação.

## Visão geral

| Camada | Volume |
| --- | --- |
| Landing / Bronze | 64.372 linhas |
| Silver (eventos válidos, sem duplicata) | 61.813 eventos em 8.793 sessões |
| Silver `eventos_rejeitados` | 1.903 eventos |
| Compras válidas | 573 pedidos, R$ 338.523,10 brutos, R$ 309.914,60 líquidos |

---

## 1. Funil: em que etapa se perde mais gente, por plano e por canal?

Tabelas: `funil_compra`, `funil_lead`.

**Total (sessões que atingiram cada etapa, sobre a etapa anterior / sobre o topo):**

| Etapa | Sessões | Sobre a anterior | Sobre o topo |
| --- | --- | --- | --- |
| `view_item_list` | 5.258 | — | 100% |
| `select_item` | 1.719 | 32,7% | 32,7% |
| `add_to_cart` | 1.291 | 75,1% | 24,6% |
| `view_cart` | 1.255 | 97,2% | 23,9% |
| `begin_checkout` | 912 | 72,7% | 17,3% |
| `add_payment_info` | 684 | 75,0% | 13,0% |
| `purchase` | 573 | 83,8% | 10,9% |

`view_item` (abrir o detalhe do plano) aparece em 985 sessões, ou 57,3% das sessões com `select_item`.

**Onde o funil vaza mais:** na passagem de ver os planos para escolher um (`view_item_list` → `select_item`), onde só 32,7% seguem. Depois disso as etapas retêm de 73% a 97%. Dentro do checkout, a maior perda é `view_cart` → `begin_checkout` (72,7%).

**Por canal** (`purchase` sobre o topo / `select_item` sobre o topo):

| Canal | select_item | purchase |
| --- | --- | --- |
| newsletter / email | 57,3% | 22,1% |
| google / cpc | 40,2% | 14,2% |
| direct / (none) | 33,5% | 11,1% |
| google / organic | 31,4% | 9,3% |
| instagram / paid_social | 17,6% | 5,1% |

O Instagram é o pior em escolher plano (17,6%), embora, quem escolhe, avance (94,2% dos que chegam ao pagamento compram). O problema desse canal está no topo do funil, não no checkout.

**Por plano** (sessões em que o primeiro `select_item` foi o plano): chegam à compra 33,3% dos que escolheram o Básico, 33,4% do Pro e 32,5% do Premium. Ou seja, a conversão depois da escolha é praticamente igual entre os planos; o Premium não perde mais gente por causa do frete ou do preço. Além disso, 11 compras estão em sessões sem `select_item` (ver "Qualidade do dado").

**Funil do e-book** (`funil_lead`): 8.382 sessões com `page_view` da landing, 5.892 (70,3%) rolaram ao menos 50% e 522 (6,2% das sessões) deixaram o e-mail. A newsletter converte mal em lead (2,6%), contra 5,7% a 6,9% nos demais canais; é esperado, porque quem vem da newsletter normalmente já é lead.

**Recomendação:** concentrar o esforço na tabela de planos (a perda de 67% entre ver e escolher): deixar o plano recomendado e a comparação mais visíveis, e testar a página com tráfego do Instagram separadamente, já que lá apenas 17,6% das sessões escolhem um plano.

---

## 2. Engajamento: o vídeo é visto até o fim? O que se procura no FAQ e não se encontra?

Tabelas: `retencao_video`, `buscas_faq`, `saidas_downloads`, `sessoes`.

**Vídeo.** Das 2.890 sessões com `video_start`:

| Marco | Sessões | % |
| --- | --- | --- |
| 10% | 2.626 | 90,9% |
| 25% | 2.138 | 74,0% |
| 50% | 1.474 | 51,0% |
| 75% | 1.105 | 38,2% |
| 100% | 877 | 30,3% |

Só 30,3% chegam ao fim. A maior queda isolada acontece entre 10% e 25% (−17 pontos) e entre 25% e 50% (−23 pontos): os primeiros minutos decidem. O botão de play é também o elemento mais clicado da landing (2.890 cliques, 34,5% das sessões com `page_view`).

**FAQ.** Foram 303 buscas (após normalizar maiúsculas e espaços). As buscas **sem resultado** concentram-se em cinco termos, e cada um deles **sempre** volta vazio:

| Termo | Buscas | Sem resultado |
| --- | --- | --- |
| estagio | 44 | 44 |
| presencial | 33 | 33 |
| bolsa | 32 | 32 |
| power bi | 28 | 28 |
| linux | 24 | 24 |

São 161 das 303 buscas (53%). Os termos com resposta (`parcelar`, `acesso`, `certificado`, `reembolso`, `apostila`) nunca falham.

**Saídas e downloads.** 366 cliques de saída para redes sociais (Instagram 102, LinkedIn 92, WhatsApp 87, YouTube 85) e 335 downloads da ementa (4,0% das sessões com `page_view`).

**Recomendação:** acrescentar ao FAQ respostas sobre estágio, aulas presenciais, bolsa, Power BI e Linux (os clientes em potencial perguntam exatamente isso), e rever os primeiros 25% do vídeo, onde se perde um quarto da audiência (e metade até o marco de 50%).

---

## 3. Receita e aquisição: quanto entrou de fato e qual canal traz cliente que não desiste?

Tabelas: `receita_diaria`, `taxa_reembolso`, `adesao_order_bump`, `lead_para_compra`.

**Receita (período inteiro):** R$ 338.523,10 brutos − R$ 28.608,50 reembolsados = **R$ 309.914,60 líquidos**, em 573 pedidos (ticket médio de R$ 590,79). Reembolsos: 48 pedidos, 8,4% do total.

**Por canal:**

| Canal | Pedidos | Receita bruta | Reembolsada | Líquida | Taxa de reembolso |
| --- | --- | --- | --- | --- | --- |
| google / cpc | 221 | 130.366,20 | 10.735,05 | **119.631,15** | 9,1% |
| direct / (none) | 112 | 63.417,20 | 1.273,95 | 62.143,25 | 1,8% |
| google / organic | 101 | 59.877,85 | 5.090,15 | 54.787,70 | 8,9% |
| newsletter / email | 74 | 46.979,80 | 1.564,15 | 45.415,65 | 2,7% |
| instagram / paid_social | 65 | 37.882,05 | 9.945,20 | 27.936,85 | **23,1%** |

**Por plano** (receita líquida): Pro R$ 145.795,65 (260 pedidos), Premium R$ 108.812,75 (120 pedidos), Básico R$ 55.306,20 (193 pedidos). O Premium vende menos de metade dos pedidos do Pro, mas gera 75% da receita dele.

**Quem não desiste:** o Instagram perde 26,3% da receita bruta em reembolsos (R$ 9.945 de R$ 37.882) e quase um em cada quatro pedidos é devolvido. Direct (1,8%) e newsletter (2,7%) praticamente não têm devolução. O Google pago traz o maior volume (R$ 119,6 mil líquidos) com reembolso próximo da média (9,1%).

**Order bump:** 15,7% das compras (90 de 573) levam a Mentoria em grupo; a adesão é parecida nos três planos (15,0% a 16,5%).

**Lead → compra:** 40 das 522 pessoas que deixaram o e-mail compraram depois (7,7%), com mediana de 4,6 dias até a compra. Por canal do lead: Google pago 9,7% (mediana 3,5 dias), Google orgânico 6,8% (1,9 dia), Instagram 5,3% (6,1 dias), direct 8,5% (7,5 dias). Newsletter tem só 14 leads (1 compra), amostra pequena para concluir qualquer coisa.

**Recomendação:** manter e ampliar o Google pago (maior receita líquida e melhor taxa de lead para compra), tratar o Instagram como canal de risco (23% de reembolso: rever a promessa dos anúncios e a segmentação, e medir o custo por cliente que fica) e investir em newsletter e direct, que têm conversão alta e quase nenhuma devolução. Como o lead leva de 2 a 7 dias para comprar, uma sequência de e-mails nesse intervalo é a melhor chance de recuperá-lo.

---

## 4. Previsão: quais sessões estão perto de comprar e que perfis existem?

Tabelas: `propensao_sessao`, `metricas_modelo`, `segmentos_visitantes`.

**Modelo de propensão.** GBTClassifier, com pesos para compensar a classe rara (6,5% das sessões compram). As features usam apenas o comportamento na landing antes do primeiro `add_to_cart` da sessão: rolagem máxima, vídeo (iniciou e maior marco), planos vistos, plano selecionado, detalhe aberto, buscas, downloads, cliques, visualizações de página, quantidade de eventos, canal e dispositivo. Nenhum evento do checkout (de `view_cart` em diante), nem `generate_lead`, `sign_up` ou `login`, entra no modelo. A divisão treino/validação/teste (60/20/20) é por visitante, para que sessões da mesma pessoa não apareçam nos dois lados, e o limiar de decisão (0,15) foi escolhido na validação.

No conjunto de teste (1.750 sessões, 114 compras):

| Métrica | Valor |
| --- | --- |
| AUC | 0,949 |
| F1 (classe "comprou") | 0,533 |
| Precisão | 0,363 |
| Recall | 1,000 |

Interpretação: o modelo encontra todas as compras do teste, mas ao custo de apontar 2,8 sessões para cada compra real (precisão de 36%). O AUC é alto em boa parte porque escolher um plano é condição para comprar: quem nunca chega a escolher um plano praticamente nunca compra, e isso é fácil de separar (não medi o AUC só dentro do grupo que escolheu plano). É um filtro útil para priorizar sessões, não um previsor preciso de quem vai pagar.

**Segmentos de visitantes.** K-Means sobre o comportamento agregado de cada pessoa (5.994 visitantes), com K escolhido por silhueta (K = 6, silhueta 0,474):

| Segmento | Visitantes | Perfil |
| --- | --- | --- |
| 0 | 1.051 | Passa e sai: ~1 sessão, ~2 eventos, rola 13%, não vê os planos |
| 4 | 2.565 | Curioso de uma visita: 1,1 sessão, ~8 eventos, rola 68%, vê planos em 0,76 sessão, nenhuma compra nem lead |
| 2 | 1.065 | Recorrente interessado: 2,3 sessões, 16 eventos, vídeo até 40%, vê planos 1,5 vez, não converte |
| 3 | 444 | Lead: 100% deixaram o e-mail, 1,7 sessão, quase nenhuma compra (0,5%) |
| 1 | 330 | Lead + ementa: baixa a ementa (1 download em média), 12% também deixa e-mail, 9,7% compra |
| 5 | 539 | Comprador: 100% compram, 2 sessões, 21 eventos, 6,7% também deixam e-mail |

**Recomendação:** o segmento 2 (1.065 visitantes, voltam e veem os planos, mas não compram nem deixam e-mail) e o 3 (444 leads que não compraram) são o público de remarketing e de e-mail. Priorizar as sessões com `probabilidade` acima do limiar de 0,15 em `propensao_sessao` para ofertas ou chat ao vivo, antes do carrinho.

---

## Qualidade do dado

### Duplicatas

656 eventos foram descartados como duplicata (mesmo `event_id`, reenvio de lote): 64.372 linhas na Bronze viram 63.716 eventos únicos. Eram cópias idênticas (mesmo `event_ts` e `event_name`).

### Rejeitados na Silver: 1.903 eventos

| Motivo | Eventos | O que era |
| --- | --- | --- |
| timestamp ausente ou futuro | 948 | 272 com `event_ts` nulo, 676 com data dez anos à frente |
| valor monetário inválido | 349 | 272 com `value` negativo, 77 com `currency = USD` |
| marco fora do padrão | 272 | `scroll` com `percent_scrolled = 33` |
| evento fora do catálogo | 271 | `add_to_wishlist` |
| reembolso sem compra | 32 | `refund` sem `purchase` válido |
| transação sem id | 31 | `purchase` sem `transaction_id` |

Cada evento recebe um único motivo, na ordem da tabela do enunciado. Os totais batem exatamente com os defeitos que o gerador declara ter injetado (por exemplo, 272 + 676 = 948 timestamps), exceto os reembolsos órfãos (32, contra 31 injetados), explicados abaixo.

### Alguma regra rejeitou dado legítimo?

Sim, por efeito colateral e não por erro da regra:

1. **Cascata nos reembolsos.** Um dos 32 reembolsos "sem compra" é legítimo: a compra dele foi rejeitada por não ter `transaction_id`, então o reembolso ficou órfão (31 eram órfãos de fato). Como é uma cascata prevista, deixei assim e registrei aqui.
2. **Compras sem id.** As 31 compras sem `transaction_id` são vendas reais (somam R$ 17.717,30 em `value`). Elas ficam de fora da receita, que portanto está subestimada em cerca de 5%. Não há como atribuí-las a reembolso nem de-duplicá-las.
3. **Reembolsos com valor negativo.** 3 reembolsos foram rejeitados por `value` negativo, então as compras correspondentes aparecem sem reembolso e a receita líquida fica ligeiramente superestimada.
4. **Eventos de funil com valor inválido.** 90 `add_to_cart`, 67 `view_cart`, 49 `begin_checkout`, 37 `add_payment_info` (e outros) saíram da Silver por valor negativo ou moeda USD. A sessão continua existindo, mas a etapa dela some, o que subconta levemente o funil.
5. **Eventos com timestamp futuro ou nulo.** Os 948 eventos podem ser eventos reais de visitantes (`page_view`, `scroll`, `select_item`, `sign_up`, ...), só com o relógio errado. Sem timestamp não dá para encaixá-los em sessão, então foram rejeitados.

### Armadilhas encontradas e como foram tratadas

1. **Duplicatas de lote (656).** Tratadas na Silver com `row_number()` por `event_id`, mantendo a cópia do arquivo mais antigo. Se o `event_id` fosse trocado no reenvio, a contagem de eventos e compras estaria inflada.
2. **`session_hint` não confiável.** Ele muda a cada recarga de página; usá-lo quebraria uma visita em várias. As sessões foram calculadas por `user_pseudo_id` com pausa de mais de 30 minutos (`lag` sobre o `event_ts`), resultando em 8.793 sessões.
3. **Eventos de mesmo instante.** Na Bronze há 949 combinações de `user_pseudo_id` + `event_ts` repetidas (parte são as cópias de lote, parte são eventos distintos no mesmo milissegundo). Para ordenar de forma estável, o desempate segue a ordem da jornada (`page_view` antes de `scroll`, `select_item` antes de `add_to_cart`) e depois o `event_id`. Isso evita que o "primeiro evento da sessão", usado para definir o canal, mude entre execuções.
4. **Identity stitching.** O `user_id` só aparece depois do login, mas vale para todo o `user_pseudo_id`. 8.736 eventos ganharam `user_id` na costura. Cada `user_pseudo_id` tem no máximo um `user_id`, e cada `user_id` está em um só navegador, então não há conflito. Esse `user_id` resolvido é a unidade de "pessoa" em `lead_para_compra` e em `segmentos_visitantes`.
5. **Sessões que atravessam a meia-noite e sessões quebradas na compra.** 11 compras estão em sessões sem `select_item` (plano `(nenhum)`): a pausa de mais de 30 minutos entre escolher o plano e pagar abriu uma sessão nova, ou o `select_item` foi rejeitado. Por isso o plano da *sessão* (primeiro `select_item`) pode diferir do plano da *compra* (item de categoria `plano`). A receita usa o plano da compra.
6. **Vazamento de informação no modelo.** Nem toda compra tem `add_to_cart` na mesma sessão, e há sessões que começam direto no checkout. Por isso, além de cortar no primeiro `add_to_cart`, o modelo só usa eventos permitidos na página `/`. Sem isso, uma sessão iniciada em `/checkout` revelaria a compra.
7. **Reembolsos órfãos em cascata.** O `refund` só vale se existir `purchase` válido com o mesmo `transaction_id`. Isso foi aplicado depois das outras regras (compra sem id, valor inválido), caso contrário o reembolso de uma compra rejeitada passaria como válido.
8. **Modo ANSI do Spark 4.** Conversões como `try_cast` e divisões com `try_divide` evitam que um texto ruim ou um denominador zero derrube o job; o valor nulo resultante vai para os rejeitados, quando for o caso.
9. **Partição `event_name`.** O `event_name` vem do caminho da landing, não do corpo do JSON. Um evento sem nome cairia em `__HIVE_DEFAULT_PARTITION__` (nulo) e seria rejeitado como fora do catálogo.

### O que não foi possível verificar

Não tenho o gabarito da correção, então não confirmei as tolerâncias de nenhuma tabela. Conferi apenas que as contagens batem com o resumo do gerador (656 duplicatas, 948 timestamps, 272 marcos, 271 fora do catálogo, 31 sem id) e que o pipeline roda do zero (`rodar_pipeline.py --do-zero`) e de novo sem duplicar a Bronze. O botão "Mapa de calor" do site não foi aberto no navegador; só confirmei que `site/mapa_calor.js` foi gerado no formato pedido.
