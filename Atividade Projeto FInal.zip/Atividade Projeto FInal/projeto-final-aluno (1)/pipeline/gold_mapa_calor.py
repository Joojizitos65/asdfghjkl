"""Job Gold mapa de calor: silver/ -> mapa_calor_cliques e mapa_calor_rolagem.

Nomes de coluna exatos (o site lê estes nomes, requisito R11):
  mapa_calor_cliques: pagina, element_id, cliques, sessoes, sessoes_na_pagina, taxa_clique, intensidade
  mapa_calor_rolagem: pagina, marco, sessoes_que_chegaram, pct_sessoes

    docker compose run --rm app python pipeline/gold_mapa_calor.py
"""

from pyspark.sql import Window
from pyspark.sql import functions as F

from comum import caminho, criar_sessao, exigir_camada, glob_eventos, ler_eventos, titulo

MARCOS = [0, 25, 50, 75, 90]
LANDING = "/"


def gravar(df, tabela: str) -> None:
    df.write.mode("overwrite").parquet(caminho(f"gold/{tabela}"))
    print(f"  gold/{tabela}: {df.count()} linhas")


def mapa_calor_cliques(ev):
    """Uma linha por página × element_id (só eventos com element_id e página)."""
    sessoes_na_pagina = (ev.filter((F.col("event_name") == "page_view") & F.col("pagina").isNotNull())
                         .groupBy("pagina").agg(F.countDistinct("session_id").alias("sessoes_na_pagina")))
    cliques = (ev.filter(F.col("element_id").isNotNull() & F.col("pagina").isNotNull())
               .groupBy("pagina", "element_id")
               .agg(F.count("*").alias("cliques"), F.countDistinct("session_id").alias("sessoes")))
    maximo_da_pagina = Window.partitionBy("pagina")
    return (cliques.join(sessoes_na_pagina, "pagina", "left")
            .withColumn("sessoes_na_pagina", F.coalesce("sessoes_na_pagina", F.lit(0)))
            .withColumn("taxa_clique", F.round(F.try_divide("sessoes", "sessoes_na_pagina"), 4))
            .withColumn("intensidade", F.round(F.try_divide("cliques", F.max("cliques").over(maximo_da_pagina)), 4))
            .select("pagina", "element_id", "cliques", "sessoes", "sessoes_na_pagina", "taxa_clique", "intensidade")
            .orderBy("pagina", F.desc("cliques")))


def mapa_calor_rolagem(spark, ev):
    """Entre as sessões com page_view na landing, quantas chegaram a cada marco de rolagem."""
    na_landing = ev.filter(F.col("pagina") == LANDING)
    base = na_landing.filter(F.col("event_name") == "page_view").select("session_id").distinct()
    maximo = (na_landing.filter(F.col("event_name") == "scroll")
              .groupBy("session_id").agg(F.max("percent_scrolled").alias("scroll_max")))
    por_sessao = base.join(maximo, "session_id", "left").cache()
    total = por_sessao.count()
    linhas = [(LANDING, m, por_sessao.filter(F.coalesce("scroll_max", F.lit(-1)) >= m).count() if m > 0 else total)
              for m in MARCOS]
    df = spark.createDataFrame(linhas, "pagina string, marco int, sessoes_que_chegaram long")
    return df.withColumn("pct_sessoes", F.round(F.try_divide("sessoes_que_chegaram", F.lit(total)), 4))


def main() -> None:
    spark = criar_sessao("gold_mapa_calor")
    exigir_camada(spark, glob_eventos("silver"), "python pipeline/silver.py")
    ev = ler_eventos(spark, "silver").cache()

    titulo("Gold mapa de calor")
    gravar(mapa_calor_cliques(ev), "mapa_calor_cliques")
    gravar(mapa_calor_rolagem(spark, ev), "mapa_calor_rolagem")

    spark.read.parquet(caminho("gold/mapa_calor_cliques")).show(40, False)
    spark.read.parquet(caminho("gold/mapa_calor_rolagem")).orderBy("marco").show(truncate=False)
    spark.stop()


if __name__ == "__main__":
    main()
