"""Script de sequência (R3): roda os oito jobs, na ordem, a partir da landing que já existe.
Ele NÃO gera dados (para isso: python gerador/gerar_eventos.py).

    docker compose run --rm app python pipeline/rodar_pipeline.py              # roda os 8 jobs
    docker compose run --rm app python pipeline/rodar_pipeline.py --do-zero    # apaga bronze/, silver/ e gold/ antes

A Bronze é append-only: sem --do-zero, os arquivos já ingeridos são pulados. Com --do-zero o
datalake é reconstruído do zero (a landing nunca é tocada). Se um job falha, a sequência para.
"""

import subprocess
import sys
import time

from comum import apagar_camada, arquivo_do_projeto, criar_sessao, titulo

JOBS = [
    "bronze.py",
    "silver.py",
    "gold_funil.py",
    "gold_engajamento.py",
    "gold_receita.py",
    "gold_ml.py",
    "gold_mapa_calor.py",
    "exportar_mapa_calor.py",
]


def apagar_camadas() -> None:
    spark = criar_sessao("do_zero")
    for camada in ("bronze", "silver", "gold"):
        print(f"apagando {camada}/ ... {'ok' if apagar_camada(spark, camada) else 'não existia'}")
    spark.stop()


def main() -> int:
    if "--do-zero" in sys.argv[1:]:
        titulo("Recomeçando do zero")
        apagar_camadas()

    pasta = arquivo_do_projeto("pipeline")
    inicio = time.time()
    for i, job in enumerate(JOBS, start=1):
        titulo(f"[{i}/{len(JOBS)}] {job}")
        t0 = time.time()
        resultado = subprocess.run([sys.executable, str(pasta / job)])
        if resultado.returncode != 0:
            print(f"\nO job {job} falhou (código {resultado.returncode}). Sequência interrompida.")
            return resultado.returncode
        print(f"\n{job} terminou em {time.time() - t0:.0f}s")

    titulo(f"Pipeline completo em {time.time() - inicio:.0f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
