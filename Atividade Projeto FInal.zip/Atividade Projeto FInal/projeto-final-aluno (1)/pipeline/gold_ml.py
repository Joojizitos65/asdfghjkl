"""Job Gold ML: silver/ -> propensao_sessao, metricas_modelo e segmentos_visitantes.

Propensão de compra por sessão (classificação), SEM vazamento de informação:
as features usam só o comportamento na landing (página "/") ANTES do primeiro add_to_cart
da sessão, e só estes eventos: page_view, scroll, vídeo, view_item_list, select_item,
view_item, site_search, file_download e click, além de canal e dispositivo.
Nada do checkout (view_cart em diante), nada de generate_lead/sign_up/login e nada de
depois do carrinho. O rótulo é "a sessão contém um purchase".

A divisão treino/validação/teste é por visitante (hash do user_pseudo_id), para que sessões
da mesma pessoa não apareçam nos dois lados. O limiar de decisão é escolhido na validação;
AUC, F1, precisão e recall (classe positiva) são medidos só no teste.

Segmentos de visitantes: K-Means sobre o comportamento agregado de cada pessoa; o K é
escolhido pela silhueta.

    docker compose run --rm app python pipeline/gold_ml.py
"""

from pyspark.ml import Pipeline
from pyspark.ml.classification import GBTClassifier
from pyspark.ml.clustering import KMeans
from pyspark.ml.evaluation import BinaryClassificationEvaluator, ClusteringEvaluator
from pyspark.ml.feature import OneHotEncoder, StandardScaler, StringIndexer, VectorAssembler
from pyspark.ml.functions import vector_to_array
from pyspark.sql import Window
from pyspark.sql import functions as F

from comum import caminho, criar_sessao, exigir_camada, glob_eventos, ler_eventos, titulo

SEMENTE = 42
# eventos que o modelo pode enxergar (comportamento na landing, antes do carrinho)
EVENTOS_PERMITIDOS = ["page_view", "scroll", "video_start", "video_progress", "video_complete",
                      "view_item_list", "select_item", "view_item", "site_search", "file_download", "click"]
NUMERICAS = ["scroll_max", "iniciou_video", "video_percent_max", "viu_planos", "selecionou_plano",
             "abriu_detalhe", "n_buscas", "n_downloads", "n_cliques", "n_page_views", "n_eventos_antes_carrinho"]
CATEGORICAS = ["canal", "dispositivo", "plano_selecionado"]


def gravar(df, tabela: str) -> None:
    df.write.mode("overwrite").parquet(caminho(f"gold/{tabela}"))
    print(f"  gold/{tabela}: {df.count()} linhas")


def montar_features(ev):
    """Uma linha por sessão: rótulo + features calculadas só com o que veio antes do primeiro add_to_cart."""
    sessoes = ev.groupBy("session_id").agg(
        F.first("user_pseudo_id").alias("user_pseudo_id"),
        F.first("canal_sessao").alias("canal"),
        F.first("dispositivo_sessao").alias("dispositivo"),
        F.max((F.col("event_name") == "purchase").cast("int")).alias("rotulo"),
        F.min(F.when(F.col("event_name") == "add_to_cart", F.col("ordem_na_sessao"))).alias("ordem_carrinho"),
    )
    pre = (ev.join(sessoes.select("session_id", "ordem_carrinho"), "session_id")
           .filter(F.col("event_name").isin(EVENTOS_PERMITIDOS)
                   & (F.col("pagina") == "/")
                   & (F.col("ordem_carrinho").isNull() | (F.col("ordem_na_sessao") < F.col("ordem_carrinho")))))

    def n(evento):
        return F.sum((F.col("event_name") == evento).cast("int"))

    feats = pre.groupBy("session_id").agg(
        F.coalesce(F.max("percent_scrolled"), F.lit(0)).alias("scroll_max"),
        F.max(F.col("event_name").isin("video_start", "video_progress", "video_complete").cast("int")).alias("iniciou_video"),
        F.coalesce(F.max("video_percent"), F.lit(0)).alias("video_percent_max"),
        F.max((F.col("event_name") == "view_item_list").cast("int")).alias("viu_planos"),
        F.max((F.col("event_name") == "select_item").cast("int")).alias("selecionou_plano"),
        F.max((F.col("event_name") == "view_item").cast("int")).alias("abriu_detalhe"),
        n("site_search").alias("n_buscas"),
        n("file_download").alias("n_downloads"),
        n("click").alias("n_cliques"),
        n("page_view").alias("n_page_views"),
        F.count("*").alias("n_eventos_antes_carrinho"),
        F.min_by(F.try_element_at("items", F.lit(1)).getField("item_id"),
                 F.when(F.col("event_name") == "select_item", F.col("ordem_na_sessao"))).alias("plano_selecionado"),
    )
    df = sessoes.join(feats, "session_id", "left")
    for c in NUMERICAS:
        df = df.withColumn(c, F.coalesce(F.col(c).cast("double"), F.lit(0.0)))
    df = df.withColumn("plano_selecionado", F.coalesce("plano_selecionado", F.lit("(nenhum)")))
    # divisão por visitante: 60% treino, 20% validação, 20% teste
    balde = F.pmod(F.hash("user_pseudo_id"), F.lit(10))
    return df.withColumn("conjunto", F.when(balde < 6, "treino").when(balde < 8, "validacao").otherwise("teste"))


def metricas_classe_positiva(df, limiar: float):
    """Precisão, recall e F1 da classe 'comprou' com o limiar dado."""
    c = df.select(
        F.sum(((F.col("probabilidade") >= limiar) & (F.col("rotulo") == 1)).cast("int")).alias("tp"),
        F.sum(((F.col("probabilidade") >= limiar) & (F.col("rotulo") == 0)).cast("int")).alias("fp"),
        F.sum(((F.col("probabilidade") < limiar) & (F.col("rotulo") == 1)).cast("int")).alias("fn"),
    ).first()
    tp, fp, fn = c["tp"] or 0, c["fp"] or 0, c["fn"] or 0
    precisao = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precisao * recall / (precisao + recall) if precisao + recall else 0.0
    return precisao, recall, f1


def propensao(spark, ev):
    df = montar_features(ev).cache()
    treino = df.filter("conjunto = 'treino'")
    positivos = treino.filter("rotulo = 1").count()
    negativos = treino.count() - positivos
    peso_positivo = negativos / positivos if positivos else 1.0     # compensa a classe rara
    df = df.withColumn("peso", F.when(F.col("rotulo") == 1, F.lit(peso_positivo)).otherwise(F.lit(1.0)))

    etapas = []
    for c in CATEGORICAS:
        etapas.append(StringIndexer(inputCol=c, outputCol=f"{c}_idx", handleInvalid="keep"))
    etapas.append(OneHotEncoder(inputCols=[f"{c}_idx" for c in CATEGORICAS],
                                outputCols=[f"{c}_vec" for c in CATEGORICAS], handleInvalid="keep"))
    etapas.append(VectorAssembler(inputCols=NUMERICAS + [f"{c}_vec" for c in CATEGORICAS], outputCol="features"))
    etapas.append(GBTClassifier(featuresCol="features", labelCol="rotulo", weightCol="peso",
                                maxIter=60, maxDepth=4, stepSize=0.1, subsamplingRate=0.8, seed=SEMENTE))
    modelo = Pipeline(stages=etapas).fit(df.filter("conjunto = 'treino'"))

    pontuado = (modelo.transform(df)
                .withColumn("probabilidade", F.round(vector_to_array("probability")[1], 6))
                .cache())

    # limiar que maximiza o F1 na validação
    validacao = pontuado.filter("conjunto = 'validacao'")
    melhor_limiar, melhor_f1 = 0.5, -1.0
    for i in range(5, 96, 5):
        limiar = i / 100
        f1 = metricas_classe_positiva(validacao, limiar)[2]
        if f1 > melhor_f1:
            melhor_limiar, melhor_f1 = limiar, f1

    teste = pontuado.filter("conjunto = 'teste'")
    auc = BinaryClassificationEvaluator(labelCol="rotulo", rawPredictionCol="rawPrediction",
                                        metricName="areaUnderROC").evaluate(teste)
    precisao, recall, f1 = metricas_classe_positiva(teste, melhor_limiar)

    saida = pontuado.select(
        "session_id", "user_pseudo_id", "conjunto", F.col("rotulo").cast("boolean").alias("comprou"),
        "probabilidade", (F.col("probabilidade") >= melhor_limiar).alias("previsto_compra"),
        *CATEGORICAS, *NUMERICAS)

    n_teste = teste.count()
    pos_teste = teste.filter("rotulo = 1").count()
    metricas = spark.createDataFrame([(
        "GBTClassifier (pesos de classe, limiar escolhido na validação)", float(round(auc, 4)),
        float(round(f1, 4)), float(round(precisao, 4)), float(round(recall, 4)), float(melhor_limiar),
        int(df.filter("conjunto = 'treino'").count()), int(validacao.count()), int(n_teste), int(pos_teste),
        NUMERICAS + CATEGORICAS,
    )], "modelo string, auc double, f1 double, precisao double, recall double, limiar double, "
        "sessoes_treino long, sessoes_validacao long, sessoes_teste long, compras_no_teste long, "
        "features array<string>")
    return saida, metricas


def segmentos(spark, ev):
    """K-Means sobre o comportamento de cada pessoa (user_id resolvido ou user_pseudo_id)."""
    pessoa = F.coalesce("user_id", "user_pseudo_id")
    por_pessoa = (ev.withColumn("visitante", pessoa)
                  .groupBy("visitante").agg(
                      F.countDistinct("session_id").alias("sessoes"),
                      F.count("*").alias("eventos"),
                      F.coalesce(F.max("percent_scrolled"), F.lit(0)).alias("scroll_max"),
                      F.coalesce(F.max("video_percent"), F.lit(0)).alias("video_percent_max"),
                      F.sum((F.col("event_name") == "view_item_list").cast("int")).alias("vezes_viu_planos"),
                      F.sum((F.col("event_name") == "site_search").cast("int")).alias("buscas"),
                      F.sum((F.col("event_name") == "file_download").cast("int")).alias("downloads"),
                      F.max((F.col("event_name") == "generate_lead").cast("int")).alias("fez_lead"),
                      F.sum((F.col("event_name") == "purchase").cast("int")).alias("compras"))
                  .cache())
    colunas = ["sessoes", "eventos", "scroll_max", "video_percent_max", "vezes_viu_planos",
               "buscas", "downloads", "fez_lead", "compras"]
    # log1p amortece os contadores muito assimétricos antes de padronizar
    base = por_pessoa
    for c in colunas:
        base = base.withColumn(f"_{c}", F.log1p(F.col(c).cast("double")))
    montado = VectorAssembler(inputCols=[f"_{c}" for c in colunas], outputCol="bruto").transform(base)
    padronizado = StandardScaler(inputCol="bruto", outputCol="features", withMean=True, withStd=True).fit(montado).transform(montado).cache()

    avaliador = ClusteringEvaluator(featuresCol="features", predictionCol="segmento", metricName="silhouette",
                                    distanceMeasure="squaredEuclidean")
    melhor = None
    for k in range(2, 7):
        previsao = KMeans(k=k, seed=SEMENTE, featuresCol="features", predictionCol="segmento", maxIter=50).fit(padronizado).transform(padronizado)
        silhueta = avaliador.evaluate(previsao)
        print(f"  K-Means k={k}: silhueta {silhueta:.4f}")
        if melhor is None or silhueta > melhor[0]:
            melhor = (silhueta, k, previsao)
    silhueta, k, previsao = melhor
    print(f"  escolhido: k={k} (silhueta {silhueta:.4f})")

    perfil = (previsao.groupBy("segmento").agg(
        F.count("*").alias("visitantes_no_segmento"),
        *[F.round(F.avg(c), 4).alias(f"perfil_{c}") for c in colunas]))
    return (previsao.join(perfil, "segmento")
            .withColumn("k", F.lit(k)).withColumn("silhueta", F.lit(round(silhueta, 4)))
            .select("visitante", "segmento", "k", "silhueta", *colunas,
                    "visitantes_no_segmento", *[f"perfil_{c}" for c in colunas]))


def main() -> None:
    spark = criar_sessao("gold_ml")
    exigir_camada(spark, glob_eventos("silver"), "python pipeline/silver.py")
    ev = ler_eventos(spark, "silver").cache()

    titulo("Gold ML")
    pontuacao, metricas = propensao(spark, ev)
    gravar(pontuacao, "propensao_sessao")
    gravar(metricas, "metricas_modelo")
    gravar(segmentos(spark, ev), "segmentos_visitantes")

    print("\nmetricas_modelo:")
    spark.read.parquet(caminho("gold/metricas_modelo")).show(truncate=False, vertical=True)
    print("segmentos (perfil médio):")
    (spark.read.parquet(caminho("gold/segmentos_visitantes"))
     .select("segmento", "visitantes_no_segmento", *[c for c in spark.read.parquet(caminho("gold/segmentos_visitantes")).columns if c.startswith("perfil_")])
     .distinct().orderBy("segmento").show(truncate=False))
    spark.stop()


if __name__ == "__main__":
    main()
