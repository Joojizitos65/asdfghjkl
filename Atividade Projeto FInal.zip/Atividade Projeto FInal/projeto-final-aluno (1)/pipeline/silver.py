"""Job Silver: bronze/ -> silver/ (dado limpo).

    R5   deduplicação por event_id
    R6   params extraídos para colunas tipadas
    R7   validação, com o motivo de rejeição (silver/eventos_rejeitados)
    R8   sessionização própria (30 min sem evento), sem usar session_hint
    R9   identity stitching (user_id propagado para todo o user_pseudo_id)
    R10  itens explodidos (silver/itens)

Saídas:
    silver/event_name=…/year=…/month=…/day=…   eventos válidos
    silver/itens/                              uma linha por item por evento
    silver/eventos_rejeitados/                 eventos recusados + motivo_rejeicao

    docker compose run --rm app python pipeline/silver.py
"""

from pyspark.sql import Window
from pyspark.sql import functions as F

from comum import (caminho, criar_sessao, exigir_camada, glob_eventos, gravar_eventos,
                   ler_eventos, titulo)

# O catálogo do contrato, na ordem da jornada. A posição serve de desempate
# quando dois eventos do mesmo visitante têm o mesmo instante.
CATALOGO = [
    "page_view", "scroll", "click", "site_search", "video_start", "video_progress",
    "video_complete", "file_download", "view_item_list", "select_item", "view_item",
    "add_to_cart", "remove_from_cart", "view_cart", "begin_checkout", "add_shipping_info",
    "add_payment_info", "purchase", "refund", "generate_lead", "sign_up", "login",
]
MARCOS_SCROLL = [25, 50, 75, 90]
MARCOS_VIDEO = [0, 10, 25, 50, 75, 100]
PAUSA_SESSAO_SEGUNDOS = 30 * 60

PARAMS_TEXTO = [
    "page_title", "link_url", "link_domain", "link_text", "link_id", "search_term", "search_area",
    "video_title", "video_provider", "file_name", "file_extension", "item_list_id",
    "item_list_name", "currency", "shipping_tier", "payment_type", "transaction_id", "coupon",
    "reason", "lead_source", "method", "element_id",
]
PARAMS_DECIMAL = ["value", "tax", "shipping", "video_duration", "video_current_time"]


def p(chave: str):
    return F.col("params").getItem(chave)


def tipar(df):
    """R6: cada chave de params vira uma coluna com o tipo certo. try_cast devolve null
    (em vez de erro, modo ANSI) quando o texto não é número; a validação trata esses casos."""
    for chave in PARAMS_TEXTO:
        df = df.withColumn(chave, p(chave))
    for chave in PARAMS_DECIMAL:
        df = df.withColumn(chave, p(chave).try_cast("double"))
    return (df
            .withColumn("percent_scrolled", p("percent_scrolled").try_cast("double"))
            .withColumn("video_percent", p("video_percent").try_cast("double"))
            .withColumn("search_results", p("search_results").try_cast("double").cast("int"))
            .withColumn("outbound", p("outbound").try_cast("boolean"))
            # texto original do valor: distingue "sem value" de "value que não é número"
            .withColumn("_value_texto", p("value"))
            .withColumn("ts", F.col("event_ts").try_cast("timestamp")))


def motivo_basico():
    """As regras do R7 que olham o evento sozinho, na ordem da tabela do enunciado.
    O primeiro motivo que casar é o gravado (um motivo por linha)."""
    return (F.when(~F.col("event_name").isin(CATALOGO) | F.col("event_name").isNull(),
                   "evento fora do catálogo")
            .when(F.col("ts").isNull() | (F.col("ts") > F.col("data_ingestao")),
                  "timestamp ausente ou futuro")
            .when(F.col("event_name").isin("purchase", "refund")
                  & (F.col("transaction_id").isNull() | (F.trim(F.col("transaction_id")) == "")),
                  "transação sem id")
            .when((F.col("value") < 0)
                  | (F.col("_value_texto").isNotNull() & F.col("value").isNull())
                  | ((F.col("value").isNotNull()) & ~F.col("currency").eqNullSafe("BRL")),
                  "valor monetário inválido")
            .when((F.col("percent_scrolled").isNotNull() & ~F.col("percent_scrolled").isin(MARCOS_SCROLL))
                  | (F.col("video_percent").isNotNull() & ~F.col("video_percent").isin(MARCOS_VIDEO)),
                  "marco fora do padrão"))


def main() -> None:
    spark = criar_sessao("silver")
    exigir_camada(spark, glob_eventos("bronze"), "python pipeline/bronze.py")

    bronze = ler_eventos(spark, "bronze")
    n_bronze = bronze.count()

    # R5: um event_id, uma linha. Fica a cópia do arquivo mais antigo (resultado determinístico).
    ordem = Window.partitionBy("event_id").orderBy("arquivo_origem", "data_ingestao")
    dedup = (bronze.withColumn("_n", F.row_number().over(ordem)).filter("_n = 1").drop("_n"))

    # R6 + R7
    tipado = tipar(dedup).cache()
    n_dedup = tipado.count()

    com_motivo = tipado.withColumn("_motivo", motivo_basico())
    compras_validas = (com_motivo
                       .filter((F.col("event_name") == "purchase") & F.col("_motivo").isNull())
                       .select(F.col("transaction_id").alias("_tx_valida")).distinct())
    com_motivo = (com_motivo.join(compras_validas, F.col("transaction_id") == F.col("_tx_valida"), "left")
                  .withColumn("motivo_rejeicao",
                              F.coalesce(F.col("_motivo"),
                                         F.when((F.col("event_name") == "refund") & F.col("_tx_valida").isNull(),
                                                F.lit("reembolso sem compra"))))
                  .cache())

    rejeitados = (com_motivo.filter(F.col("motivo_rejeicao").isNotNull())
                  .select("event_id", "event_name", "event_ts", "user_pseudo_id", "user_id",
                          "page", "traffic", "device", "params", "items", "arquivo_origem",
                          "data_ingestao", "year", "month", "day", "motivo_rejeicao"))
    validos = com_motivo.filter(F.col("motivo_rejeicao").isNull())

    # R9: identity stitching. O user_id aparece depois do login, mas vale para o navegador todo.
    # Usa todos os eventos deduplicados (inclusive os rejeitados), que também carregam o user_id.
    identidade = (tipado.filter(F.col("user_id").isNotNull())
                  .groupBy("user_pseudo_id").agg(F.min("user_id").alias("_user_id_costurado")))
    validos = (validos.join(identidade, "user_pseudo_id", "left")
               .withColumn("user_id_original", F.col("user_id"))
               .withColumn("user_id", F.col("_user_id_costurado")))

    # R8: sessões. Cada evento olha o anterior do mesmo user_pseudo_id; pausa > 30 min abre sessão nova.
    ord_evento = F.array_position(F.array(*[F.lit(e) for e in CATALOGO]), F.col("event_name"))
    validos = validos.withColumn("_ord", ord_evento)
    por_visitante = Window.partitionBy("user_pseudo_id").orderBy("ts", "_ord", "event_id")
    anterior = F.lag("ts").over(por_visitante)
    nova_sessao = (anterior.isNull()
                   | ((F.col("ts").cast("double") - anterior.cast("double")) > PAUSA_SESSAO_SEGUNDOS))
    validos = (validos.withColumn("_nova", nova_sessao.cast("int"))
               .withColumn("_seq", F.sum("_nova").over(por_visitante.rowsBetween(Window.unboundedPreceding, 0)))
               .withColumn("session_id", F.concat_ws("-", F.col("user_pseudo_id"), F.concat(F.lit("s"), F.col("_seq")))))

    na_sessao = Window.partitionBy("session_id").orderBy("ts", "_ord", "event_id")
    sessao_toda = na_sessao.rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
    primeiro_select = F.when(F.col("event_name") == "select_item", F.col("items").getItem(0).getField("item_id"))
    validos = (validos
               .withColumn("ordem_na_sessao", F.row_number().over(na_sessao))
               .withColumn("canal_sessao",
                           F.concat_ws(" / ", F.first("traffic.source").over(sessao_toda),
                                       F.first("traffic.medium").over(sessao_toda)))
               .withColumn("dispositivo_sessao", F.first("device.category").over(sessao_toda))
               .withColumn("plano_sessao",
                           F.coalesce(F.first(primeiro_select, ignorenulls=True).over(sessao_toda),
                                      F.lit("(nenhum)"))))

    # página: caminho de page_location, sem domínio, sem ? e sem #; a raiz vira "/"
    caminho_pagina = F.regexp_extract(F.col("page.location"), r"^[a-zA-Z][a-zA-Z0-9+.-]*://[^/?#]+([^?#]*)", 1)
    pagina = (F.when(F.col("page.location").isNull(), F.lit(None))
              .when(caminho_pagina == "", F.lit("/")).otherwise(caminho_pagina))

    silver = (validos
              .withColumn("event_ts", F.col("ts"))
              .withColumn("data_evento", F.to_date("ts"))
              .withColumn("pagina", pagina)
              .withColumn("page_location", F.col("page.location"))
              .withColumn("page_referrer", F.col("page.referrer"))
              .withColumn("source", F.col("traffic.source"))
              .withColumn("medium", F.col("traffic.medium"))
              .withColumn("campaign", F.col("traffic.campaign"))
              .withColumn("device_category", F.col("device.category"))
              .withColumn("os", F.col("device.os"))
              .withColumn("browser", F.col("device.browser"))
              .withColumn("percent_scrolled", F.col("percent_scrolled").cast("int"))
              .withColumn("video_percent", F.col("video_percent").cast("int"))
              .select("event_id", "event_ts", "data_evento", "user_pseudo_id", "user_id", "user_id_original",
                      "session_id", "ordem_na_sessao", "canal_sessao", "dispositivo_sessao", "plano_sessao",
                      "page_location", "page_referrer", "pagina", "source", "medium", "campaign",
                      "device_category", "os", "browser",
                      *PARAMS_TEXTO, *PARAMS_DECIMAL,
                      "percent_scrolled", "video_percent", "search_results", "outbound",
                      "items", "arquivo_origem", "data_ingestao",
                      "event_name", "year", "month", "day")
              .cache())
    n_validos = silver.count()

    # R10: uma linha por item por evento
    itens = (silver.filter(F.size("items") > 0)
             .select("event_id", "event_name", "event_ts", "user_pseudo_id", "user_id", "session_id",
                     "transaction_id", F.posexplode("items").alias("item_pos", "item"),
                     "year", "month", "day")
             .select("event_id", "event_name", "event_ts", "user_pseudo_id", "user_id", "session_id",
                     "transaction_id", "item_pos",
                     F.col("item.item_id").alias("item_id"),
                     F.col("item.item_name").alias("item_name"),
                     F.col("item.item_category").alias("item_category"),
                     F.col("item.price").alias("price"),
                     F.col("item.quantity").alias("quantity"),
                     "year", "month", "day"))

    gravar_eventos(silver, "silver", "overwrite")
    itens.write.mode("overwrite").partitionBy("year", "month", "day").parquet(caminho("silver/itens"))
    rejeitados.write.mode("overwrite").parquet(caminho("silver/eventos_rejeitados"))

    titulo("Silver")
    n_rej = rejeitados.count()
    print(f"eventos na Bronze:            {n_bronze}")
    print(f"duplicatas descartadas (R5):  {n_bronze - n_dedup}")
    print(f"eventos únicos:               {n_dedup}")
    print(f"válidos (silver):             {n_validos}")
    print(f"rejeitados:                   {n_rej}")
    rejeitados.groupBy("motivo_rejeicao").count().orderBy(F.desc("count")).show(truncate=False)
    print("rejeitados por motivo e evento:")
    rejeitados.groupBy("motivo_rejeicao", "event_name").count().orderBy("motivo_rejeicao", F.desc("count")).show(40, False)
    print(f"linhas em silver/itens:       {itens.count()}")
    print(f"sessões:                      {silver.select('session_id').distinct().count()}")
    costurados = silver.filter(F.col("user_id_original").isNull() & F.col("user_id").isNotNull()).count()
    print(f"eventos que ganharam user_id no stitching: {costurados}")
    spark.stop()


if __name__ == "__main__":
    main()
