"""Job Gold funil: silver/ -> gold/funil_compra e gold/funil_lead.

Regra do funil (5.4, item 4): uma sessão conta numa etapa se teve aquele evento em
qualquer momento, sem exigir as etapas anteriores.
Canal e plano da sessão vêm da Silver (canal do primeiro evento; item do primeiro select_item).

    docker compose run --rm app python pipeline/gold_funil.py
"""

from pyspark.sql import Window
from pyspark.sql import functions as F

from comum import caminho, criar_sessao, exigir_camada, glob_eventos, ler_eventos, titulo

ETAPAS = ["view_item_list", "select_item", "add_to_cart", "view_cart",
          "begin_checkout", "add_payment_info", "purchase"]
TODOS = "(todos)"


def gravar(df, tabela: str) -> None:
    df.write.mode("overwrite").parquet(caminho(f"gold/{tabela}"))
    print(f"  gold/{tabela}: {df.count()} linhas")


def tem(evento: str):
    return F.max((F.col("event_name") == evento).cast("int"))


def rotulo_todos(coluna: str):
    """O cube devolve null no total; troca por um texto legível."""
    return F.coalesce(F.col(coluna), F.lit(TODOS)).alias(coluna)


def funil_compra(ev):
    sessoes = ev.groupBy("session_id").agg(
        F.first("plano_sessao").alias("plano"),
        F.first("canal_sessao").alias("canal"),
        *[tem(e).alias(e) for e in ETAPAS],
        tem("view_item").alias("view_item"),
    )
    # total, por plano, por canal e por plano × canal
    soma = sessoes.cube("plano", "canal").agg(*[F.sum(e).alias(e) for e in ETAPAS],
                                             F.sum("view_item").alias("view_item"))
    soma = soma.select(rotulo_todos("plano"), rotulo_todos("canal"), *ETAPAS, "view_item")

    longo = soma.select(
        "plano", "canal", "view_item",
        F.explode(F.array(*[F.struct(F.lit(i + 1).alias("etapa_ordem"), F.lit(e).alias("etapa"),
                                     F.col(e).cast("long").alias("sessoes"))
                            for i, e in enumerate(ETAPAS)])).alias("x"),
    ).select("plano", "canal", "view_item", "x.etapa_ordem", "x.etapa", "x.sessoes")

    janela = Window.partitionBy("plano", "canal").orderBy("etapa_ordem")
    funil = (longo
             .withColumn("conv_etapa_anterior", F.round(F.try_divide("sessoes", F.lag("sessoes").over(janela)), 4))
             .withColumn("conv_topo", F.round(F.try_divide("sessoes", F.first("sessoes").over(janela)), 4)))

    # view_item é opcional na jornada: fica fora da sequência, como taxa à parte
    # (sessões com view_item ÷ sessões com select_item)
    select = longo.filter(F.col("etapa") == "select_item").select("plano", "canal", F.col("sessoes").alias("_select"))
    opcional = (longo.select("plano", "canal", "view_item").distinct()
                .join(select, ["plano", "canal"])
                .select("plano", "canal", F.lit(None).cast("int").alias("etapa_ordem"),
                        F.lit("view_item (opcional)").alias("etapa"),
                        F.col("view_item").cast("long").alias("sessoes"),
                        F.round(F.try_divide("view_item", "_select"), 4).alias("conv_etapa_anterior"),
                        F.lit(None).cast("double").alias("conv_topo")))

    cols = ["plano", "canal", "etapa_ordem", "etapa", "sessoes", "conv_etapa_anterior", "conv_topo"]
    return funil.select(*cols).unionByName(opcional.select(*cols))


def funil_lead(ev):
    na_landing = F.col("pagina") == "/"
    sessoes = ev.groupBy("session_id").agg(
        F.first("canal_sessao").alias("canal"),
        F.max(((F.col("event_name") == "page_view") & na_landing).cast("int")).alias("page_view_landing"),
        F.max(((F.col("event_name") == "scroll") & na_landing & (F.col("percent_scrolled") >= 50)).cast("int")).alias("scroll_50"),
        tem("generate_lead").alias("generate_lead"),
    )
    soma = (sessoes.cube("canal")
            .agg(F.sum("page_view_landing").alias("sessoes_page_view_landing"),
                 F.sum("scroll_50").alias("sessoes_scroll_50"),
                 F.sum("generate_lead").alias("sessoes_generate_lead"))
            .select(rotulo_todos("canal"), "sessoes_page_view_landing", "sessoes_scroll_50", "sessoes_generate_lead"))
    return (soma
            .withColumn("conv_scroll_sobre_page_view", F.round(F.try_divide("sessoes_scroll_50", "sessoes_page_view_landing"), 4))
            .withColumn("conv_lead_sobre_scroll", F.round(F.try_divide("sessoes_generate_lead", "sessoes_scroll_50"), 4))
            .withColumn("conv_lead_sobre_page_view", F.round(F.try_divide("sessoes_generate_lead", "sessoes_page_view_landing"), 4))
            .orderBy("canal"))


def main() -> None:
    spark = criar_sessao("gold_funil")
    exigir_camada(spark, glob_eventos("silver"), "python pipeline/silver.py")
    ev = ler_eventos(spark, "silver").cache()

    titulo("Gold funil")
    gravar(funil_compra(ev), "funil_compra")
    gravar(funil_lead(ev), "funil_lead")

    print("\nfunil_compra (total):")
    (spark.read.parquet(caminho("gold/funil_compra"))
     .filter((F.col("plano") == TODOS) & (F.col("canal") == TODOS))
     .orderBy(F.col("etapa_ordem").asc_nulls_last()).show(truncate=False))
    print("funil_lead:")
    spark.read.parquet(caminho("gold/funil_lead")).show(truncate=False)
    spark.stop()


if __name__ == "__main__":
    main()
