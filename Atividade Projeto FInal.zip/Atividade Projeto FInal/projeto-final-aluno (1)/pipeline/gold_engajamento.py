"""Job Gold engajamento: silver/ -> sessoes, retencao_video, buscas_faq, saidas_downloads.

    docker compose run --rm app python pipeline/gold_engajamento.py
"""

from pyspark.sql import functions as F

from comum import caminho, criar_sessao, exigir_camada, glob_eventos, ler_eventos, titulo

MARCOS_VIDEO = [10, 25, 50, 75, 100]


def gravar(df, tabela: str) -> None:
    df.write.mode("overwrite").parquet(caminho(f"gold/{tabela}"))
    print(f"  gold/{tabela}: {df.count()} linhas")


def sessoes(ev):
    """Uma linha por sessão."""
    return (ev.groupBy("session_id").agg(
        F.first("user_pseudo_id").alias("user_pseudo_id"),
        F.max("user_id").alias("user_id"),
        F.min("event_ts").alias("inicio"),
        F.max("event_ts").alias("fim"),
        F.count("*").alias("eventos"),
        F.coalesce(F.max("percent_scrolled"), F.lit(0)).alias("scroll_max"),
        F.max((F.col("event_name") == "video_start").cast("int")).cast("boolean").alias("iniciou_video"),
        F.coalesce(F.max("video_percent"), F.lit(0)).alias("video_percent_max"),
        F.max((F.col("event_name") == "generate_lead").cast("int")).cast("boolean").alias("fez_lead"),
        F.max((F.col("event_name") == "purchase").cast("int")).cast("boolean").alias("comprou"),
        F.first("canal_sessao").alias("canal"),
        F.first("dispositivo_sessao").alias("dispositivo"),
        F.first("plano_sessao").alias("plano"),
    ).withColumn("duracao_seg", F.round(F.col("fim").cast("double") - F.col("inicio").cast("double"), 3))
     .select("session_id", "user_pseudo_id", "user_id", "inicio", "fim", "duracao_seg", "eventos",
             "scroll_max", "iniciou_video", "video_percent_max", "fez_lead", "comprou",
             "canal", "dispositivo", "plano"))


def retencao_video(ev):
    """Das sessões com video_start, o percentual que atingiu 10, 25, 50, 75 e 100%."""
    por_sessao = ev.groupBy("session_id").agg(
        F.max((F.col("event_name") == "video_start").cast("int")).alias("iniciou"),
        F.coalesce(F.max("video_percent"), F.lit(0)).alias("maximo"),
    ).filter("iniciou = 1")
    base = por_sessao.count()
    linhas = [por_sessao.agg(F.lit(m).alias("marco_percent"),
                             F.lit(base).alias("sessoes_com_video_start"),
                             F.sum((F.col("maximo") >= m).cast("int")).cast("long").alias("sessoes_que_atingiram"))
              for m in MARCOS_VIDEO]
    uniao = linhas[0]
    for linha in linhas[1:]:
        uniao = uniao.unionByName(linha)
    return uniao.withColumn("pct_sessoes", F.round(F.try_divide("sessoes_que_atingiram", "sessoes_com_video_start"), 4))


def buscas_faq(ev):
    """Termo normalizado (minúsculas, sem espaços nas pontas), total de buscas e buscas sem resultado."""
    return (ev.filter(F.col("event_name") == "site_search")
            .withColumn("termo", F.lower(F.trim("search_term")))
            .groupBy("termo")
            .agg(F.count("*").alias("total_buscas"),
                 F.sum((F.col("search_results") == 0).cast("int")).cast("long").alias("buscas_sem_resultado"))
            .withColumn("pct_sem_resultado", F.round(F.try_divide("buscas_sem_resultado", "total_buscas"), 4))
            .orderBy(F.desc("buscas_sem_resultado"), F.desc("total_buscas")))


def saidas_downloads(ev):
    """Cliques de saída por domínio e downloads por arquivo, numa tabela só (coluna tipo)."""
    saidas = (ev.filter((F.col("event_name") == "click") & (F.col("outbound") == True))  # noqa: E712
              .groupBy(F.lit("saida").alias("tipo"), F.lower("link_domain").alias("chave")))
    downloads = (ev.filter(F.col("event_name") == "file_download")
                 .groupBy(F.lit("download").alias("tipo"), F.col("file_name").alias("chave")))
    agregados = [g.agg(F.count("*").alias("total"), F.countDistinct("session_id").alias("sessoes"))
                 for g in (saidas, downloads)]
    return agregados[0].unionByName(agregados[1]).orderBy("tipo", F.desc("total"))


def main() -> None:
    spark = criar_sessao("gold_engajamento")
    exigir_camada(spark, glob_eventos("silver"), "python pipeline/silver.py")
    ev = ler_eventos(spark, "silver").cache()

    titulo("Gold engajamento")
    gravar(sessoes(ev), "sessoes")
    gravar(retencao_video(ev), "retencao_video")
    gravar(buscas_faq(ev), "buscas_faq")
    gravar(saidas_downloads(ev), "saidas_downloads")

    print("\nretencao_video:")
    spark.read.parquet(caminho("gold/retencao_video")).orderBy("marco_percent").show(truncate=False)
    print("buscas_faq:")
    spark.read.parquet(caminho("gold/buscas_faq")).show(truncate=False)
    print("saidas_downloads:")
    spark.read.parquet(caminho("gold/saidas_downloads")).show(truncate=False)
    spark.stop()


if __name__ == "__main__":
    main()
