"""Job Bronze: landing/ (JSON Lines) -> bronze/ (Parquet).

Cópia fiel do que chegou, sem limpar nada:
  * schema explícito (sem inferência), R4;
  * particionada por event_name/year/month/day, onde year/month/day é o dia de
    coleta tirado do caminho da landing;
  * colunas de proveniência: arquivo_origem e data_ingestao;
  * append-only: só acrescenta. Arquivos da landing que já estão na Bronze são
    pulados, então rodar o job de novo não duplica nada.

    docker compose run --rm app python pipeline/bronze.py
"""

from pyspark.sql import functions as F
from pyspark.sql import types as T

from comum import (caminho, camada_existe, criar_sessao, exigir_camada, glob_eventos,
                   gravar_eventos, ler_eventos, titulo)

# O event_name não entra no schema: ele vem da pasta event_name=… (partição). Evento sem
# event_name cai em __HIVE_DEFAULT_PARTITION__ e chega como nulo.
# params é um map<string,string>: as chaves variam por evento e os tipos são aplicados na Silver (R6).
SCHEMA_LANDING = T.StructType([
    T.StructField("event_id", T.StringType()),
    T.StructField("event_ts", T.StringType()),
    T.StructField("user_pseudo_id", T.StringType()),
    T.StructField("user_id", T.StringType()),
    T.StructField("session_hint", T.StringType()),
    T.StructField("page", T.StructType([
        T.StructField("location", T.StringType()),
        T.StructField("referrer", T.StringType()),
    ])),
    T.StructField("traffic", T.StructType([
        T.StructField("source", T.StringType()),
        T.StructField("medium", T.StringType()),
        T.StructField("campaign", T.StringType()),
    ])),
    T.StructField("device", T.StructType([
        T.StructField("category", T.StringType()),
        T.StructField("os", T.StringType()),
        T.StructField("browser", T.StringType()),
    ])),
    T.StructField("params", T.MapType(T.StringType(), T.StringType())),
    T.StructField("items", T.ArrayType(T.StructType([
        T.StructField("item_id", T.StringType()),
        T.StructField("item_name", T.StringType()),
        T.StructField("item_category", T.StringType()),
        T.StructField("price", T.DoubleType()),
        T.StructField("quantity", T.LongType()),
    ]))),
])


def main() -> None:
    spark = criar_sessao("bronze")
    exigir_camada(spark, glob_eventos("landing"), "python gerador/gerar_eventos.py")

    landing = ler_eventos(spark, "landing", "json", schema=SCHEMA_LANDING)
    bronze = (landing
              .withColumn("arquivo_origem", F.col("_metadata.file_path"))
              .withColumn("data_ingestao", F.current_timestamp()))

    # append-only e idempotente: ignora os arquivos que já foram ingeridos
    if camada_existe(spark, glob_eventos("bronze")):
        ja_ingeridos = ler_eventos(spark, "bronze").select("arquivo_origem").distinct()
        bronze = bronze.join(ja_ingeridos, "arquivo_origem", "left_anti")

    bronze = bronze.select("event_id", "event_ts", "user_pseudo_id", "user_id", "session_hint",
                           "page", "traffic", "device", "params", "items",
                           "arquivo_origem", "data_ingestao",
                           "event_name", "year", "month", "day")

    # cache: o count e a gravação leem o mesmo resultado (e a data_ingestao fica igual nos dois)
    bronze = bronze.cache()
    novos = bronze.count()
    if novos:
        gravar_eventos(bronze, "bronze", "append")

    titulo("Bronze")
    total = ler_eventos(spark, "bronze").count() if camada_existe(spark, glob_eventos("bronze")) else 0
    print(f"linhas novas gravadas: {novos}")
    print(f"linhas na Bronze:      {total}")
    print(f"destino:               {caminho('bronze')}")
    spark.stop()


if __name__ == "__main__":
    main()
