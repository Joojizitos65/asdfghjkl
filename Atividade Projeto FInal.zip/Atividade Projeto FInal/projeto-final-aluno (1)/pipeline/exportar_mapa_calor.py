"""Job de exportação (R11): gold/mapa_calor_* -> site/mapa_calor.js.

Lê as duas tabelas Gold pelo Spark (R1) e grava um arquivo local, de uma linha só:
    window.MAPA_CALOR = {"gerado_em": "...", "cliques": [...], "rolagem": [...]};
Só as duas tabelas pequenas (poucas dezenas de linhas) vêm para o Python com collect().

    docker compose run --rm app python pipeline/exportar_mapa_calor.py
"""

import json
from datetime import datetime, timezone

from comum import arquivo_do_projeto, camada_existe, caminho, criar_sessao, titulo


def main() -> None:
    spark = criar_sessao("exportar_mapa_calor")
    for tabela in ("mapa_calor_cliques", "mapa_calor_rolagem"):
        if not camada_existe(spark, f"gold/{tabela}"):
            spark.stop()
            raise SystemExit(f"{caminho('gold/' + tabela)} não existe. Rode antes: python pipeline/gold_mapa_calor.py")

    cliques = [l.asDict() for l in spark.read.parquet(caminho("gold/mapa_calor_cliques")).collect()]
    rolagem = [l.asDict() for l in spark.read.parquet(caminho("gold/mapa_calor_rolagem")).collect()]
    agora = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    dados = {"gerado_em": agora, "cliques": cliques, "rolagem": rolagem}

    destino = arquivo_do_projeto("site/mapa_calor.js")
    texto = json.dumps(dados, ensure_ascii=False, default=float)
    destino.write_text("window.MAPA_CALOR = " + texto + ";\n", encoding="utf-8")

    titulo("Exportação do mapa de calor")
    print(f"{len(cliques)} linhas de cliques, {len(rolagem)} de rolagem -> {destino}")
    spark.stop()


if __name__ == "__main__":
    main()
