"""Job Gold receita e aquisição: silver/ -> receita_diaria, taxa_reembolso,
adesao_order_bump e lead_para_compra.

Definições (5.4): receita bruta = soma de value dos purchase válidos; reembolsada = soma de value
dos refund válidos, atribuída à compra pelo transaction_id; líquida = bruta − reembolsada;
datas em UTC; canal da compra = canal da sessão; plano da compra = item de categoria "plano".

    docker compose run --rm app python pipeline/gold_receita.py
"""

from pyspark.sql import functions as F

from comum import caminho, criar_sessao, exigir_camada, glob_eventos, ler_eventos, titulo

TODOS = "(todos)"


def gravar(df, tabela: str) -> None:
    df.write.mode("overwrite").parquet(caminho(f"gold/{tabela}"))
    print(f"  gold/{tabela}: {df.count()} linhas")


def rotulo_todos(coluna: str, texto: str = TODOS):
    return F.coalesce(F.col(coluna), F.lit(texto)).alias(coluna)


def montar_compras(ev):
    """Uma linha por compra válida, com o reembolso atribuído pelo transaction_id."""
    planos = F.filter("items", lambda i: i["item_category"] == "plano")
    compras = (ev.filter(F.col("event_name") == "purchase")
               .select("transaction_id", F.col("event_ts").alias("ts_compra"),
                       F.col("data_evento").alias("data_compra"),
                       F.col("value").alias("valor"),
                       F.col("canal_sessao").alias("canal"),
                       F.coalesce(F.try_element_at(planos, F.lit(1)).getField("item_id"), F.lit("(sem plano)")).alias("plano"),
                       F.exists("items", lambda i: i["item_id"] == "BUMP-MENTORIA").alias("com_bump")))
    reembolsos = (ev.filter(F.col("event_name") == "refund")
                  .groupBy("transaction_id")
                  .agg(F.sum("value").alias("valor_reembolsado"), F.count("*").alias("n_reembolsos")))
    return (compras.join(reembolsos, "transaction_id", "left")
            .withColumn("valor_reembolsado", F.coalesce("valor_reembolsado", F.lit(0.0)))
            .withColumn("n_reembolsos", F.coalesce("n_reembolsos", F.lit(0))))


def receita_diaria(compras):
    return (compras.groupBy("data_compra", "plano", "canal")
            .agg(F.round(F.sum("valor"), 2).alias("receita_bruta"),
                 F.round(F.sum("valor_reembolsado"), 2).alias("receita_reembolsada"),
                 F.count("*").alias("pedidos"))
            .withColumn("receita_liquida", F.round(F.col("receita_bruta") - F.col("receita_reembolsada"), 2))
            .withColumn("ticket_medio", F.round(F.try_divide("receita_bruta", "pedidos"), 2))
            .select("data_compra", "plano", "canal", "receita_bruta", "receita_reembolsada",
                    "receita_liquida", "pedidos", "ticket_medio")
            .orderBy("data_compra", "plano", "canal"))


def taxa_reembolso(compras):
    """pedidos com reembolso ÷ pedidos, por plano e canal da compra (com os totais)."""
    return (compras.cube("plano", "canal")
            .agg(F.count("*").alias("pedidos"),
                 F.sum((F.col("n_reembolsos") > 0).cast("int")).cast("long").alias("pedidos_com_reembolso"))
            .select(rotulo_todos("plano"), rotulo_todos("canal"), "pedidos", "pedidos_com_reembolso")
            .withColumn("taxa_reembolso", F.round(F.try_divide("pedidos_com_reembolso", "pedidos"), 4))
            .orderBy("plano", "canal"))


def adesao_order_bump(compras):
    return (compras.cube("plano")
            .agg(F.count("*").alias("compras"),
                 F.sum(F.col("com_bump").cast("int")).cast("long").alias("compras_com_bump"))
            .select(rotulo_todos("plano"), "compras", "compras_com_bump")
            .withColumn("pct_adesao", F.round(F.try_divide("compras_com_bump", "compras"), 4))
            .orderBy("plano"))


def lead_para_compra(ev):
    """Por pessoa (user_id resolvido, ou user_pseudo_id): primeiro generate_lead e primeira compra
    estritamente depois dele. Dias = segundos ÷ 86400; mediana com percentile_approx."""
    pessoa = F.coalesce("user_id", "user_pseudo_id").alias("pessoa")
    leads = (ev.filter(F.col("event_name") == "generate_lead")
             .select(pessoa, "event_ts", "ordem_na_sessao", "canal_sessao")
             .groupBy("pessoa")
             .agg(F.min("event_ts").alias("ts_lead"),
                  F.min_by("canal_sessao", F.struct("event_ts", "ordem_na_sessao")).alias("canal_lead")))
    compras = (ev.filter(F.col("event_name") == "purchase")
               .select(pessoa, F.col("event_ts").alias("ts_compra")))
    depois = (leads.join(compras, (leads["pessoa"] == compras["pessoa"]) & (compras["ts_compra"] > leads["ts_lead"]), "left")
              .groupBy(leads["pessoa"], "canal_lead", "ts_lead")
              .agg(F.min("ts_compra").alias("ts_primeira_compra"))
              .withColumn("dias", (F.col("ts_primeira_compra").cast("double") - F.col("ts_lead").cast("double")) / 86400))
    return (depois.cube("canal_lead")
            .agg(F.count("*").alias("leads"),
                 F.count("ts_primeira_compra").alias("leads_que_compraram"),
                 F.expr("percentile_approx(dias, 0.5)").alias("mediana_dias_ate_compra"))
            .select(rotulo_todos("canal_lead").alias("canal_lead"), "leads", "leads_que_compraram",
                    F.round(F.try_divide("leads_que_compraram", "leads"), 4).alias("taxa_lead_para_compra"),
                    F.round("mediana_dias_ate_compra", 4).alias("mediana_dias_ate_compra"))
            .orderBy("canal_lead"))


def main() -> None:
    spark = criar_sessao("gold_receita")
    exigir_camada(spark, glob_eventos("silver"), "python pipeline/silver.py")
    ev = ler_eventos(spark, "silver").cache()
    compras = montar_compras(ev).cache()

    titulo("Gold receita e aquisição")
    gravar(receita_diaria(compras), "receita_diaria")
    gravar(taxa_reembolso(compras), "taxa_reembolso")
    gravar(adesao_order_bump(compras), "adesao_order_bump")
    gravar(lead_para_compra(ev), "lead_para_compra")

    print("\nreceita total:")
    (spark.read.parquet(caminho("gold/receita_diaria"))
     .agg(F.sum("receita_bruta").alias("bruta"), F.sum("receita_reembolsada").alias("reembolsada"),
          F.sum("receita_liquida").alias("liquida"), F.sum("pedidos").alias("pedidos")).show())
    print("taxa_reembolso:")
    spark.read.parquet(caminho("gold/taxa_reembolso")).filter(
        (F.col("plano") == TODOS) | (F.col("canal") == TODOS)).show(30, False)
    print("adesao_order_bump:")
    spark.read.parquet(caminho("gold/adesao_order_bump")).show(truncate=False)
    print("lead_para_compra:")
    spark.read.parquet(caminho("gold/lead_para_compra")).show(truncate=False)
    spark.stop()


if __name__ == "__main__":
    main()
